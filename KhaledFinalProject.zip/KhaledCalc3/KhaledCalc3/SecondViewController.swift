//
//  SecondViewController.swift
//  KhaledCalc3
//
//  Created by home on 2024-08-01.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
