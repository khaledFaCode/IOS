//
//  ViewController.swift
//  KhaledCalc4
//
//  Created by home on 2024-06-08.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var calculatorWorkings: UILabel!
    @IBOutlet weak var calculatorResults: UILabel!
    
    var workings: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        clearAll()
    }
    
    func clearAll() {
        workings = ""
        calculatorWorkings.text = ""
        calculatorResults.text = ""
    }
    
    @IBAction func equalsTap(_ sender: Any) {
        if validInput() {
            let sanitizedWorkings = sanitizeWorkings(workings)
            
            // Check if sanitized workings is non-empty and valid
            if sanitizedWorkings.isEmpty {
                return
            }
            
            do {
                let expression = NSExpression(format: sanitizedWorkings)
                if let result = expression.expressionValue(with: nil, context: nil) as? Double {
                    if result.isFinite {
                        let resultString = formatResult(result: result)
                        calculatorResults.text = resultString
                    } else {
                        showAlert(message: "Result is not a finite number.")
                    }
                } else {
                    showAlert(message: "Unable to calculate the result.")
                }
            } catch {
                showAlert(message: "Error evaluating expression.")
            }
        } else {
            showAlert(message: "Invalid input.")
        }
    }
    
    func validInput() -> Bool {
        let specialChars = Set(["*", "/", "+", "-"])
        var count = 0
        var funcCharIndexes = [Int]()
        
        for char in workings {
            if specialChars.contains(String(char)) {
                funcCharIndexes.append(count)
            }
            count += 1
        }
        
        var previous: Int = -1
        
        for index in funcCharIndexes {
            if index == 0 || index == workings.count - 1 {
                return false
            }
            
            if previous != -1 && index - previous == 1 {
                return false
            }
            
            previous = index
        }
        
        // Check for multiple decimals in a single number
        let numbers = workings.components(separatedBy: CharacterSet(charactersIn: "+-*/"))
        for number in numbers {
            if number.contains(".") {
                let decimalCount = number.components(separatedBy: ".").count - 1
                if decimalCount > 1 {
                    return false
                }
            }
        }
        
        // Ensure that the expression does not end with an operator or decimal point
        if workings.last == nil || "+-*/.".contains(workings.last!) {
            return false
        }
        
        // Check for cases like "0.+3" or "3*." which are invalid
        let invalidPatterns = ["0\\+\\.", "\\+\\.", "\\.\\d+", "\\d+\\." ]
        for pattern in invalidPatterns {
            if workings.range(of: pattern, options: .regularExpression) != nil {
                return false
            }
        }
        
        return true
    }
    
    func sanitizeWorkings(_ workings: String) -> String {
        let sanitized = workings.replacingOccurrences(of: "%", with: "*0.01")
        
        // Ensure that there are no invalid characters or incomplete expressions
        let validCharacters = CharacterSet(charactersIn: "0123456789+-*/%.() ")
        let inputCharacterSet = CharacterSet(charactersIn: sanitized)
        
        if !validCharacters.isSuperset(of: inputCharacterSet) {
            showAlert(message: "Input contains invalid characters.")
            return ""
        }
        
        // Check for invalid patterns
        let invalidPatterns = ["*%", "/%", "+%", "-%", "++", "--", "**", "//", "/*", "/+", "+/", "*+", "+*"]
        for pattern in invalidPatterns {
            if sanitized.contains(pattern) {
                showAlert(message: "Input contains invalid patterns.")
                return ""
            }
        }
        
        return sanitized
    }
    
    func formatResult(result: Double) -> String {
        if result.truncatingRemainder(dividingBy: 1) == 0 {
            return String(format: "%.0f", result)
        } else {
            return String(format: "%.2f", result)
        }
    }
    
    @IBAction func allClearTap(_ sender: Any) {
        clearAll()
    }
    
    @IBAction func backTap(_ sender: Any) {
        if !workings.isEmpty {
            workings.removeLast()
            calculatorWorkings.text = workings
        }
    }
    
    func addToWorkings(value: String) {
        workings.append(value)
        calculatorWorkings.text = workings
    }
    
    @IBAction func percentTap(_ sender: Any) {
        addToWorkings(value: "%")
    }
    
    @IBAction func divideTap(_ sender: Any) {
        addToWorkings(value: "/")
    }
    
    @IBAction func timesTap(_ sender: Any) {
        addToWorkings(value: "*")
    }
    
    @IBAction func minusTap(_ sender: Any) {
        addToWorkings(value: "-")
    }
    
    @IBAction func plusTap(_ sender: Any) {
        addToWorkings(value: "+")
    }
    
    @IBAction func decimalTap(_ sender: Any) {
        // Prevent adding a decimal point if one already exists in the current number
        let components = workings.split { "+-*/".contains($0) }
        let lastComponent = components.last ?? ""
        
        if lastComponent.contains(".") {
            // If the last number already contains a decimal point, don't add another
            return
        }
        
        if lastComponent.isEmpty {
            addToWorkings(value: "0.")
        } else {
            addToWorkings(value: ".")
        }
    }
    
    @IBAction func zeroTap(_ sender: Any) {
        addToWorkings(value: "0")
    }
    
    @IBAction func oneTap(_ sender: Any) {
        addToWorkings(value: "1")
    }
    
    @IBAction func twoTap(_ sender: Any) {
        addToWorkings(value: "2")
    }
    
    @IBAction func threeTap(_ sender: Any) {
        addToWorkings(value: "3")
    }
    
    @IBAction func fourTap(_ sender: Any) {
        addToWorkings(value: "4")
    }
    
    @IBAction func fiveTap(_ sender: Any) {
        addToWorkings(value: "5")
    }
    
    @IBAction func sixTap(_ sender: Any) {
        addToWorkings(value: "6")
    }
    
    @IBAction func sevenTap(_ sender: Any) {
        addToWorkings(value: "7")
    }
    
    @IBAction func eightTap(_ sender: Any) {
        addToWorkings(value: "8")
    }
    
    @IBAction func nineTap(_ sender: Any) {
        addToWorkings(value: "9")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationItem.setHidesBackButton(true, animated: true)
    }
    
    private func showAlert(message: String) {
        let alert = UIAlertController(
            title: "Error",
            message: message,
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "Okay", style: .default))
        self.present(alert, animated: true, completion: nil)
    }
}
