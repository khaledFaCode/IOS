import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else {
            print("Failed to get windowScene")
            return
        }
        
        print("Window Scene Initialized")

        // Initialize the window
        window = UIWindow(windowScene: windowScene)
        
        // Instantiate Navigation Controller from the storyboard
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let navigationController = storyboard.instantiateInitialViewController() as? UINavigationController else {
            print("Failed to instantiate NavigationController")
            return
        }
        
        
        window?.rootViewController = navigationController
        window?.makeKeyAndVisible()
        
        print("NavigationController set as root view controller")
    }

    func sceneDidDisconnect(_ scene: UIScene) {
        print("Scene did disconnect")
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
        print("Scene did become active")
    }

    func sceneWillResignActive(_ scene: UIScene) {
        print("Scene will resign active")
    }

    func sceneWillEnterForeground(_ scene: UIScene) {
        print("Scene will enter foreground")
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
        print("Scene did enter background")
    }
}
