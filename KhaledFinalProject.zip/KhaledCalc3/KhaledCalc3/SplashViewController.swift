import UIKit

class SplashViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Delay transition to MainViewController
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { // 2 seconds delay
            self.transitionToMainViewController()
        }
    }

    private func transitionToMainViewController() {
        // Instantiate MainViewController from the storyboard
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let mainViewController = storyboard.instantiateViewController(withIdentifier: "MainViewController") as? ViewController {
            
            // Find the active scene
            if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
                if let window = windowScene.windows.first {
                    // Set the window's root view controller to MainViewController
                    window.rootViewController = mainViewController
                    UIView.transition(with: window, duration: 0.5, options: .transitionCrossDissolve, animations: nil, completion: nil)
                }
            }
        }
    }
}
